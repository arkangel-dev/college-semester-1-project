var searchData=
[
  ['nqueens_5fexample_5fsolutionlistoperations_5fh',['NQueens_Example_SolutionListOperations_h',['../_solution_list_operations_8h.html#a2c8d103e230697785d5096ccea1b39c6',1,'SolutionListOperations.h']]],
  ['nqueenschecker_2eh',['NQueensChecker.h',['../_n_queens_checker_8h.html',1,'']]],
  ['numberofdefinedvalues',['numberOfDefinedValues',['../structcandidate_solution.html#aa8031610c543386d706ee7bc50b1d835',1,'candidateSolution']]]
];
