var searchData=
[
  ['nqueenschecker_2eh',['NQueensChecker.h',['../_n_queens_checker_8h.html',1,'']]]
];
