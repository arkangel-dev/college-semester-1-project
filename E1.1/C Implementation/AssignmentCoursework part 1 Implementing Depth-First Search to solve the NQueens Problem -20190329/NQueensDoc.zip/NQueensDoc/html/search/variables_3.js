var searchData=
[
  ['score',['score',['../structcandidate_solution.html#a9faa155b4dc280a8cec9756ac019cb9e',1,'candidateSolution']]]
];
