var searchData=
[
  ['movequeeninrowtonewcol',['MoveQueenInRowToNewCol',['../_n_queens_checker_8h.html#afb985ead7654c8eb0489271a63b196e2',1,'NQueensChecker.c']]]
];
