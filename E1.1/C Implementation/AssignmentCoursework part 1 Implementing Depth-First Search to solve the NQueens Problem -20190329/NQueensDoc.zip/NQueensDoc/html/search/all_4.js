var searchData=
[
  ['indexoflastentryadded',['indexOfLastEntryAdded',['../structcandidate_list.html#a8d34bc217c2cbfdcda7b18912791762c',1,'candidateList']]]
];
