var searchData=
[
  ['nqueens_5fexample_5fsolutionlistoperations_5fh',['NQueens_Example_SolutionListOperations_h',['../_solution_list_operations_8h.html#a2c8d103e230697785d5096ccea1b39c6',1,'SolutionListOperations.h']]]
];
