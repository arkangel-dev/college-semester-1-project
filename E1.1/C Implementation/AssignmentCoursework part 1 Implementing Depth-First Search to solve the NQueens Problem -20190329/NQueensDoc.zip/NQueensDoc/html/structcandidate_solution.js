var structcandidate_solution =
[
    [ "numberOfDefinedValues", "structcandidate_solution.html#aa8031610c543386d706ee7bc50b1d835", null ],
    [ "score", "structcandidate_solution.html#a9faa155b4dc280a8cec9756ac019cb9e", null ],
    [ "variableValues", "structcandidate_solution.html#ae0873f5da29f83eb81d7e6babf52833e", null ]
];