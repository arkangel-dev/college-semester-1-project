var _solution_list_operations_8h =
[
    [ "NQueens_Example_SolutionListOperations_h", "_solution_list_operations_8h.html#a2c8d103e230697785d5096ccea1b39c6", null ],
    [ "AddSolutionPram1_ToListParam2", "_solution_list_operations_8h.html#aab9de6fd249c08a9e8082afbc0a361d3", null ],
    [ "AddWorkingCandidateToCurrentList", "_solution_list_operations_8h.html#aa6d63cb9d1084f94d369de7b63d754f1", null ],
    [ "AddWorkingCandidateToExaminedList", "_solution_list_operations_8h.html#ab4eb8569e9e0ae5beac37067ead564c6", null ],
    [ "ChangeWorkingCandidateByReplaceValueinPlaceParam1_WithValueParam2", "_solution_list_operations_8h.html#ab118562edf8e78e0e5c688d765da43ce", null ],
    [ "CleanCandidate", "_solution_list_operations_8h.html#ac6a5bab994eb479d61f83c349448760d", null ],
    [ "CleanListsOfSolutionsToStart", "_solution_list_operations_8h.html#afaff8a05238b1a51aa8a7564b45c3738", null ],
    [ "CleanWorkingCandidate", "_solution_list_operations_8h.html#abd29866c061f2080a5e092d96052c1a9", null ],
    [ "CopySolutionFromCurrentListIntoWorkingCandidate", "_solution_list_operations_8h.html#a7296ba43b834dbed7ebb41283bf08ad9", null ],
    [ "CopySolutionParam1_IntoSolutionParam2", "_solution_list_operations_8h.html#a2fdbf6f3795da62d86cc7c24d9c6c0f0", null ],
    [ "ExtendWorkingCandidateByAddingValue", "_solution_list_operations_8h.html#a772d5dadc98a4fbe52e53bd723812738", null ],
    [ "GetIndexOfWorkingCandidateInThisList", "_solution_list_operations_8h.html#a8f398756346415d2d24f0213914d6fc7", null ],
    [ "PrintThisMessageAndExit", "_solution_list_operations_8h.html#a793ef952c5d67f28f8e3662892783112", null ],
    [ "PrintWorkingCandidate", "_solution_list_operations_8h.html#a2d6ef0d5eae034ad22469bc5dd0b2883", null ],
    [ "RemoveFromListParam1_CandidateSolutionAtIndexParam2", "_solution_list_operations_8h.html#ae0e346a2a0a5c8d4de50f4c37d41d487", null ],
    [ "RemoveSolutionFromCurrentList", "_solution_list_operations_8h.html#a698b1b069df933cafd757a71bee35101", null ]
];