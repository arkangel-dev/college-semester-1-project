var files =
[
    [ "main.c", "main_8c_source.html", null ],
    [ "NQueensChecker.c", "_n_queens_checker_8c_source.html", null ],
    [ "NQueensChecker.h", "_n_queens_checker_8h.html", "_n_queens_checker_8h" ],
    [ "NQueensDefinitions.h", "_n_queens_definitions_8h_source.html", null ],
    [ "SolutionListOperations.c", "_solution_list_operations_8c_source.html", null ],
    [ "SolutionListOperations.h", "_solution_list_operations_8h.html", "_solution_list_operations_8h" ],
    [ "StructureDefinitions.h", "_structure_definitions_8h.html", "_structure_definitions_8h" ]
];