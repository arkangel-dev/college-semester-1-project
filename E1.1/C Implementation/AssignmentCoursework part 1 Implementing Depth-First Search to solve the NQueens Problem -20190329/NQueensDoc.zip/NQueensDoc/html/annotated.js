var annotated =
[
    [ "candidateList", "structcandidate_list.html", "structcandidate_list" ],
    [ "candidateSolution", "structcandidate_solution.html", "structcandidate_solution" ]
];